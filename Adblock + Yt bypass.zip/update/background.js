let isAdblockEnabled = true;

chrome.storage.sync.get('adblockEnabled', function(data) {
    isAdblockEnabled = data.adblockEnabled !== undefined ? data.adblockEnabled : true;
    updateIcon();
    updateRules();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleAdblock') {
        isAdblockEnabled = request.state;
        chrome.storage.sync.set({ adblockEnabled: isAdblockEnabled }, () => {
            updateIcon();
            updateRules();
            sendResponse({ status: 'success' });
        });
        return true;
    }
});

function updateIcon() {
    const iconPath = isAdblockEnabled ? 'images/green_icon.png' : 'images/red_icon.png';
    chrome.action.setIcon({ path: iconPath });
}

function updateRules() {
    if (isAdblockEnabled) {
        chrome.declarativeNetRequest.updateEnabledRulesets({
            enableRulesetIds: ['ruleset_1'],
            disableRulesetIds: []
        });
    } else {
        chrome.declarativeNetRequest.updateEnabledRulesets({
            enableRulesetIds: [],
            disableRulesetIds: ['ruleset_1']
        });
    }
}
