document.addEventListener('DOMContentLoaded', function () {
    // Fetch the current Chrome theme colors
    chrome.storage.sync.get(['--background-color', '--text-color', '--accent-color'], function (result) {
        // Apply the fetched colors to the popup
        const body = document.querySelector('body');
        body.style.backgroundColor = result['--background-color'];
        body.style.color = result['--text-color'];

        // Add event listener for toggle switch
        const toggle = document.getElementById('toggle');
        toggle.addEventListener('change', function () {
            // Send message to background script to update the adblock state and icon
            chrome.runtime.sendMessage({
                action: 'toggleAdblock',
                state: toggle.checked
            }, function(response) {
                if (response.status === 'success') {
                    const status = document.getElementById('status');
                    status.textContent = toggle.checked ? 'AdBlock Enabled' : 'AdBlock Disabled';
                }
            });
        });

        // Initialize toggle switch based on stored state
        chrome.storage.sync.get('adblockEnabled', function (data) {
            toggle.checked = data.adblockEnabled || false;

            // Update status message initially
            const status = document.getElementById('status');
            if (toggle.checked) {
                status.textContent = 'AdBlock Enabled';
            } else {
                status.textContent = 'AdBlock Disabled';
            }
        });
    });
});
