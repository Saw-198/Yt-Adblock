
document.addEventListener('DOMContentLoaded', function() {
    var elements = document.querySelectorAll('.adblock-message, .anti-adblock');
    elements.forEach(function(element) {
        element.remove();
    });
});
